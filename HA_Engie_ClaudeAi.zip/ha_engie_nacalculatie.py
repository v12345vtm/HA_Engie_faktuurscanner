"""
ENGIE nacalculatie, stap 2 van 2: energie_historiek.json -> energie_prijzen.json

Plaats in:        /config/pyscript/modules/ha_engie_nacalculatie.py
Gebruikt door:    /config/pyscript/ha_engie_facturen.py

Dezelfde logica als energie_prijzen.py (PyCharm). Per factuur (= 1 maand) wordt voor
elektriciteit en gas berekend:
  - ENERGIEPRIJS: enkel 'afname', dus excl. BTW, excl. netwerkkosten, excl. toeslagen/heffingen
  - ALL-IN PRIJS: afname + netwerk + toeslagen, incl. BTW
  - een controle: kloppen de rubrieken met het subtotaal/de eindsom van de factuur?

Naast energie_prijzen.json (in /media/engie/extracteddata) wordt een kopie weggeschreven in
/config/www/engie/, zodat ha_engie_resume.html ze kan lezen. Let op: alles in /config/www is
via /local zonder login bereikbaar.

De berekening is native python (@pyscript_compile) en bewust zelfstandig, net als de scanner.
"""

# ---------------------------------------------------------------------------
# INSTELLINGEN
# ---------------------------------------------------------------------------
BTW_PCT = 6.0           # !! controleer: BTW op elektriciteit en gas voor jouw periode
KWH_PER_M3 = 11.4       # vaste omrekenfactor gas voor de prijs per m3
DECIMALEN_BEDRAG = 2    # bedragen in EUR
DECIMALEN_PRIJS = 4     # eenheidsprijzen in EUR/kWh
TOLERANTIE = 0.02       # toegelaten verschil (EUR) bij de controle tegen de factuurtotalen


@pyscript_compile
def _bereken_native(invoer, uitvoer, web_uitvoer, btw_pct, kwh_per_m3, dec_bedrag, dec_prijs, tolerantie):
    """Draait in een thread (task.executor). Geeft een dict met de prijzen en meldingen terug."""
    import json
    import re
    from datetime import date, datetime
    from pathlib import Path

    meldingen = []

    # ------------------------------------------------------------------
    # Hulpfuncties: uit energie_prijzen.py
    # ------------------------------------------------------------------
    def bedrag(x):
        return None if x is None else round(x, dec_bedrag)

    def prijs(x):
        return None if x is None else round(x, dec_prijs)

    def g(d, key):
        """Waarde uit dict als float, None wordt 0.0."""
        return float(d.get(key) or 0.0)

    def parse_periode(tekst):
        """'01.08.2026 - 31.08.2026' -> (date(2026,8,1), date(2026,8,31))"""
        m = re.search(r"(\d{2})\.(\d{2})\.(\d{4})\s*-\s*(\d{2})\.(\d{2})\.(\d{4})", tekst or "")
        if not m:
            raise ValueError(f"facturatieperiode onleesbaar: {tekst!r}")
        d1, m1, y1, d2, m2, y2 = map(int, m.groups())
        return date(y1, m1, d1), date(y2, m2, d2)

    def schoon_contract(tekst):
        """Haalt postcode + gemeente weg die de scanner soms voor de contractnaam meeneemt."""
        if not tekst:
            return tekst
        return re.sub(r"^\d{4}\s+[A-ZÀ-Ý\-\s]+?\s(?=[A-Z][a-zà-ý])", "", tekst).strip()

    def sectie(afname, netwerk, toeslag, kwh):
        """Onafgeronde berekening voor 1 energiesoort."""
        excl = afname + netwerk + toeslag
        btw = excl * btw_pct / 100
        incl = excl + btw
        return {
            "excl": excl,
            "btw": btw,
            "incl": incl,
            "prijs_kwh": incl / kwh,          # all-in, incl. BTW
            "energie_kwh": afname / kwh,      # enkel afname: excl. BTW, netwerk en toeslagen
        }

    def schrijf_json(pad, data):
        """Atomisch wegschrijven: eerst een .tmp-bestand, dan vervangen."""
        pad.parent.mkdir(parents=True, exist_ok=True)
        tmp = pad.with_name(pad.name + ".tmp")
        tmp.write_text(json.dumps(data, indent=4, ensure_ascii=False), encoding="utf-8")
        tmp.replace(pad)

    # ------------------------------------------------------------------
    # 1 factuur verwerken
    # ------------------------------------------------------------------
    def verwerk_factuur(f):
        van, tot = parse_periode(f.get("facturatieperiode"))
        elek_raw = dict(f.get("elektriciteit") or {})
        gas_raw = dict(f.get("aardgas") or {})
        totalen = f.get("totaalbedragen") or {}
        opm = []

        # Scanner-bug opvangen: factuur met enkel gas. De scanner kent de eerste
        # netwerkkost/toeslag altijd aan elektriciteit toe.
        heeft_elek = any(elek_raw.get(k) is not None for k in ("ean", "afname_engie", "totaal_afname_kwh"))
        if (not heeft_elek and gas_raw.get("netwerkkosten") is None
                and (elek_raw.get("netwerkkosten") is not None or elek_raw.get("toeslagen_en_heffingen") is not None)):
            gas_raw["netwerkkosten"] = elek_raw.get("netwerkkosten")
            gas_raw["toeslagen_en_heffingen"] = elek_raw.get("toeslagen_en_heffingen")
            elek_raw["netwerkkosten"] = None
            elek_raw["toeslagen_en_heffingen"] = None
            opm.append("Netwerkkosten/toeslagen stonden onder elektriciteit maar horen bij gas (enkel gasfactuur): verplaatst.")

        # --- Elektriciteit ---
        elek = None
        elek_kwh = elek_raw.get("totaal_afname_kwh")
        if elek_kwh is None and (elek_raw.get("piek_kwh") is not None or elek_raw.get("dal_kwh") is not None):
            elek_kwh = g(elek_raw, "piek_kwh") + g(elek_raw, "dal_kwh")
        if elek_kwh and elek_kwh > 0:
            a, n, t = g(elek_raw, "afname_engie"), g(elek_raw, "netwerkkosten"), g(elek_raw, "toeslagen_en_heffingen")
            s = sectie(a, n, t, elek_kwh)
            elek = {
                "kwh": elek_kwh,
                "piek_kwh": elek_raw.get("piek_kwh"),
                "dal_kwh": elek_raw.get("dal_kwh"),
                "afname": bedrag(a),
                "netwerk": bedrag(n),
                "toeslag": bedrag(t),
                "subtotaal_excl_btw": bedrag(s["excl"]),
                "btw": bedrag(s["btw"]),
                "totaal_incl_btw": bedrag(s["incl"]),
                "energieprijs_excl_btw_per_kwh": prijs(s["energie_kwh"]),
                "eenheidsprijs_incl_btw": prijs(s["prijs_kwh"]),
            }

        # --- Gas ---
        gas = None
        gas_kwh = gas_raw.get("verbruik_kwh")
        gas_m3 = gas_raw.get("verbruik_m3")
        if gas_kwh and gas_kwh > 0:
            a, n, t = g(gas_raw, "verbruik_engie"), g(gas_raw, "netwerkkosten"), g(gas_raw, "toeslagen_en_heffingen")
            s = sectie(a, n, t, gas_kwh)
            gas = {
                "kwh": gas_kwh,
                "m3_factuur": gas_m3,
                "kwh_per_m3_factuur": round(gas_kwh / gas_m3, 2) if gas_m3 else None,
                "afname": bedrag(a),
                "netwerk": bedrag(n),
                "toeslag": bedrag(t),
                "subtotaal_excl_btw": bedrag(s["excl"]),
                "btw": bedrag(s["btw"]),
                "totaal_incl_btw": bedrag(s["incl"]),
                "energieprijs_excl_btw_per_kwh": prijs(s["energie_kwh"]),
                "energieprijs_excl_btw_per_m3": prijs(s["energie_kwh"] * kwh_per_m3),
                "eenheidsprijs_incl_btw_per_kwh": prijs(s["prijs_kwh"]),
                "eenheidsprijs_incl_btw_per_m3": prijs(s["prijs_kwh"] * kwh_per_m3),
            }

        # --- Controle tegen de totalen op de factuur ---
        som_excl = sum(g(elek_raw, k) for k in ("afname_engie", "netwerkkosten", "toeslagen_en_heffingen")) \
            + sum(g(gas_raw, k) for k in ("verbruik_engie", "netwerkkosten", "toeslagen_en_heffingen"))
        f_excl, f_btw, f_incl = (totalen.get(k) for k in ("totaal_excl_btw", "btw", "totaal_incl_btw"))

        if None in (f_excl, f_btw, f_incl):
            ok = False
            verschil_excl = verschil_incl = None
            opm.append("Totalen van de factuur ontbreken in de scan: controle niet mogelijk.")
        else:
            verschil_excl = som_excl - f_excl
            verschil_incl = som_excl * (1 + btw_pct / 100) - f_incl
            ok = abs(verschil_excl) <= tolerantie and abs(verschil_incl) <= tolerantie
            if not ok:
                opm.append("Rubrieken komen niet overeen met de totalen van de factuur: scan nakijken.")
        if elek is None and gas is None:
            ok = False
            opm.append("Geen verbruik (kWh) gevonden voor elektriciteit of gas.")

        return {
            "periode": f"{van.month:02d}/{van.year}",
            "periode_van": van.isoformat(),
            "periode_tot": tot.isoformat(),
            "factuurnummer": f.get("factuurnummer"),
            "contract": schoon_contract(f.get("contract")),
            "btw_pct": btw_pct,
            "elektriciteit": elek,
            "gas": gas,
            "totalen_factuur": {
                "subtotaal_excl_btw": f_excl,
                "btw": f_btw,
                "eindsom_incl_btw": f_incl,
            },
            "controle": {
                "ok": ok,
                "verschil_excl_btw": bedrag(verschil_excl),
                "verschil_incl_btw": bedrag(verschil_incl),
                "opmerkingen": opm,
            },
        }

    # ------------------------------------------------------------------
    # Alles samenbrengen
    # ------------------------------------------------------------------
    def meest_recente(periodes):
        """Laatste bekende prijs per energiesoort (de nieuwste periode mét die soort)."""
        res = {"elektriciteit": None, "gas": None}
        for p in periodes:                      # periodes zijn al chronologisch
            e, gs = p["elektriciteit"], p["gas"]
            basis = {
                "periode": p["periode"],
                "periode_van": p["periode_van"],
                "periode_tot": p["periode_tot"],
                "factuurnummer": p["factuurnummer"],
                "controle_ok": p["controle"]["ok"],
            }
            if e:
                res["elektriciteit"] = dict(
                    basis,
                    energie_eur_per_kwh_excl_btw=e["energieprijs_excl_btw_per_kwh"],
                    all_in_eur_per_kwh_incl_btw=e["eenheidsprijs_incl_btw"],
                )
            if gs:
                res["gas"] = dict(
                    basis,
                    energie_eur_per_kwh_excl_btw=gs["energieprijs_excl_btw_per_kwh"],
                    energie_eur_per_m3_excl_btw=gs["energieprijs_excl_btw_per_m3"],
                    all_in_eur_per_kwh_incl_btw=gs["eenheidsprijs_incl_btw_per_kwh"],
                    all_in_eur_per_m3_incl_btw=gs["eenheidsprijs_incl_btw_per_m3"],
                )
        return res

    def bouw_prijzen(facturen):
        periodes, fouten = {}, []
        for f in facturen:
            nr = f.get("factuurnummer") or f.get("bronbestand") or "?"
            try:
                rec = verwerk_factuur(f)
            except Exception as e:                  # 1 slechte factuur mag de rest niet blokkeren
                fouten.append(f"Factuur {nr}: {e}")
                continue
            if rec["periode"] in periodes:
                oud = periodes[rec["periode"]]["factuurnummer"]
                rec["controle"]["opmerkingen"].append(f"Zelfde periode als factuur {oud}: die is vervangen.")
            periodes[rec["periode"]] = rec

        lijst = sorted(periodes.values(), key=lambda p: p["periode_van"])
        return {
            "gegenereerd": datetime.now().astimezone().isoformat(timespec="seconds"),
            "instellingen": {
                "btw_pct": btw_pct,
                "kwh_per_m3": kwh_per_m3,
                "decimalen_bedrag": dec_bedrag,
                "decimalen_prijs": dec_prijs,
            },
            "meest_recente": meest_recente(lijst),
            "periodes": lijst,
        }, fouten

    # ------------------------------------------------------------------
    # Hoofdlogica
    # ------------------------------------------------------------------
    resultaat = {
        "tijdstip": datetime.now().astimezone().isoformat(timespec="seconds"),
        "prijzen": None,
        "periodes": 0,
        "controle_fouten": 0,
        "fouten": [],
        "meldingen": meldingen,
    }

    invoer_pad = Path(invoer)
    if not invoer_pad.exists():
        meldingen.append(("warning", f"{invoer} bestaat nog niet: eerst de PDF-facturen scannen"))
        return resultaat

    try:
        facturen = json.loads(invoer_pad.read_text(encoding="utf-8"))
        prijzen, fouten = bouw_prijzen(facturen)
        resultaat["prijzen"] = prijzen
        resultaat["periodes"] = len(prijzen["periodes"])
        resultaat["fouten"] = fouten

        for p in prijzen["periodes"]:
            if not p["controle"]["ok"]:
                resultaat["controle_fouten"] += 1
            for o in p["controle"]["opmerkingen"]:
                niveau = "info" if p["controle"]["ok"] else "warning"
                meldingen.append((niveau, f"[{p['periode']}] {o}"))
        for fout in fouten:
            meldingen.append(("error", fout))

        uitvoer_pad = Path(uitvoer)
        bestond = uitvoer_pad.exists()
        schrijf_json(uitvoer_pad, prijzen)
        meldingen.append((
            "info",
            f"{uitvoer_pad.name} {'bijgewerkt' if bestond else 'aangemaakt'}: {resultaat['periodes']} periodes",
        ))

        if web_uitvoer:
            try:
                schrijf_json(Path(web_uitvoer), prijzen)
                meldingen.append(("info", f"kopie voor ha_engie_resume.html geschreven naar {web_uitvoer}"))
            except OSError as e:
                meldingen.append(("warning", f"kopie voor ha_engie_resume.html niet geschreven ({e})"))

        for soort in ("elektriciteit", "gas"):
            m = prijzen["meest_recente"][soort]
            if m:
                meldingen.append((
                    "info",
                    f"meest recente prijs {soort} ({m['periode']}): "
                    f"{m['energie_eur_per_kwh_excl_btw'] * 100:.2f} c/kWh excl., "
                    f"{m['all_in_eur_per_kwh_incl_btw']:.4f} EUR/kWh all-in",
                ))

    except Exception as e:
        resultaat["fouten"].append(str(e))
        meldingen.append(("error", f"nacalculatie mislukt: {e}"))

    return resultaat


def engie_nacalculatie(invoer, uitvoer, web_uitvoer):
    """Berekent de prijzen. De verwerking draait in een thread via task.executor."""
    return task.executor(
        _bereken_native, invoer, uitvoer, web_uitvoer,
        BTW_PCT, KWH_PER_M3, DECIMALEN_BEDRAG, DECIMALEN_PRIJS, TOLERANTIE,
    )
