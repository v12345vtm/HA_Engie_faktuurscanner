"""
ENGIE-facturen verwerken in Home Assistant (pyscript)
=====================================================
Plaats in: /config/pyscript/ha_engie_facturen.py

Service:  pyscript.verwerk_engie_facturen          (optionele velden: herstart, debug)
Loopt ook automatisch bij het opstarten van HA. Sensoren die met state.set() worden gemaakt
bestaan na een herstart immers niet meer, tot ze opnieuw gezet worden.

Bestanden
  /config/pyscript/ha_engie_facturen.py                dit bestand: service, sensoren, log
  /config/pyscript/modules/ha_engie_pdf2json.py        stap 1: PDF's -> energie_historiek.json
  /config/pyscript/modules/ha_engie_nacalculatie.py    stap 2: prijsberekening (BTW_PCT enz.)
  /config/www/engie/ha_engie_resume.html               overzichtspagina, te openen via
                                                       /local/engie/ha_engie_resume.html
  /media/engie/                                        hier komen de PDF-facturen
  /media/engie/extracteddata/                          energie_historiek.json, energie_prijzen.json

Installatie
  1. Voeg 'pdfplumber' toe aan /config/pyscript/requirements.txt (onder qrcode), herstart HA.
  2. Zet de PDF's in /media/engie en roep pyscript.verwerk_engie_facturen aan.

Sensoren
  sensor.incl_engie_elektriciteit_kwh   EUR/kWh   all-in: afname + netwerk + toeslagen + btw
  sensor.incl_engie_gas_kwh             EUR/kWh
  sensor.incl_engie_gas_m3              EUR/m³
  sensor.excl_engie_elektriciteit_kwh   c€/kWh    enkel afname: excl. btw, netwerk en toeslagen
  sensor.excl_engie_gas_kwh             c€/kWh
  sensor.engie_facturen_status          resultaat van de laatste verwerking

Log
  Samenvattingen staan op info-niveau. Wil je die in het HA-log zien, zet dan in
  configuration.yaml:
      logger:
        logs:
          custom_components.pyscript: info
  Foutmelding "import of ... not allowed"? Zet 'Allow All Imports' aan bij de pyscript-integratie.
"""
from ha_engie_pdf2json import engie_pdf2json
from ha_engie_nacalculatie import engie_nacalculatie

# ---------------------------------------------------------------------------
# INSTELLINGEN
# ---------------------------------------------------------------------------
PDF_MAP = "/media/engie"
DATA_MAP = "/media/engie/extracteddata"
HISTORIEK_JSON = DATA_MAP + "/energie_historiek.json"
PRIJZEN_JSON = DATA_MAP + "/energie_prijzen.json"
DEBUG_MAP = DATA_MAP + "/debug"
WEB_JSON = "/config/www/engie/energie_prijzen.json"     # wordt gelezen door ha_engie_resume.html

STATUS_SENSOR = "sensor.engie_facturen_status"

# (entity_id, naam, eenheid, icoon, soort, sleutel in 'meest_recente', factor, decimalen)
SENSOREN = [
    ("sensor.incl_engie_elektriciteit_kwh", "ENGIE elektriciteit all-in (incl. btw)",
     "EUR/kWh", "mdi:flash", "elektriciteit", "all_in_eur_per_kwh_incl_btw", 1, 4),
    ("sensor.incl_engie_gas_kwh", "ENGIE gas all-in per kWh (incl. btw)",
     "EUR/kWh", "mdi:fire", "gas", "all_in_eur_per_kwh_incl_btw", 1, 4),
    ("sensor.incl_engie_gas_m3", "ENGIE gas all-in per m³ (incl. btw)",
     "EUR/m³", "mdi:fire", "gas", "all_in_eur_per_m3_incl_btw", 1, 4),
    ("sensor.excl_engie_elektriciteit_kwh", "ENGIE elektriciteit energieprijs (excl. btw)",
     "c€/kWh", "mdi:flash", "elektriciteit", "energie_eur_per_kwh_excl_btw", 100, 2),
    ("sensor.excl_engie_gas_kwh", "ENGIE gas energieprijs (excl. btw)",
     "c€/kWh", "mdi:fire", "gas", "energie_eur_per_kwh_excl_btw", 100, 2),
]

_TOESTAND = {"bezig": False}


def _log_meldingen(stap, meldingen):
    """Zet de meldingen uit de native functies in het HA-log."""
    for niveau, tekst in meldingen:
        bericht = "Engie " + stap + ": " + tekst
        if niveau == "error":
            log.error(bericht)
        elif niveau == "warning":
            log.warning(bericht)
        elif niveau == "debug":
            log.debug(bericht)
        else:
            log.info(bericht)


def _zet_sensoren(meest_recente):
    """Zet de 5 prijssensoren op de meest recente prijzen."""
    aantal = 0
    for entity_id, naam, eenheid, icoon, soort, sleutel, factor, decimalen in SENSOREN:
        m = meest_recente.get(soort)
        attributen = {"friendly_name": naam, "unit_of_measurement": eenheid, "icon": icoon}
        waarde = "unknown"
        if m:
            ruw = m.get(sleutel)
            if ruw is not None:
                waarde = round(ruw * factor, decimalen)
            attributen["periode"] = m.get("periode")
            attributen["periode_van"] = m.get("periode_van")
            attributen["periode_tot"] = m.get("periode_tot")
            attributen["factuurnummer"] = m.get("factuurnummer")
            attributen["controle_ok"] = m.get("controle_ok")
        state.set(entity_id, waarde, new_attributes=attributen)
        aantal += 1
    return aantal


def _zet_status(niveau, tekst, tijdstip, extra):
    attributen = {
        "friendly_name": "ENGIE facturen, laatste verwerking",
        "icon": "mdi:file-document-multiple-outline",
        "status": niveau,
        "laatste_run": tijdstip,
        "pdf_map": PDF_MAP,
    }
    attributen.update(extra)
    state.set(STATUS_SENSOR, tekst[:250], new_attributes=attributen)


def _voer_uit(herstart=False, debug=False):
    if _TOESTAND["bezig"]:
        log.warning("Engie: er loopt al een verwerking, deze aanvraag wordt overgeslagen")
        return
    _TOESTAND["bezig"] = True
    try:
        log.info(f"Engie: verwerking gestart (herstart={herstart}, debug={debug})")

        # Stap 1: PDF's -> energie_historiek.json (zware verwerking in een thread)
        r1 = engie_pdf2json(PDF_MAP, HISTORIEK_JSON, DEBUG_MAP, herstart, debug)
        _log_meldingen("pdf2json", r1["meldingen"])

        # Stap 2: nacalculatie -> energie_prijzen.json (+ kopie voor de html)
        r2 = engie_nacalculatie(HISTORIEK_JSON, PRIJZEN_JSON, WEB_JSON)
        _log_meldingen("nacalculatie", r2["meldingen"])

        if r2["prijzen"]:
            aantal = _zet_sensoren(r2["prijzen"]["meest_recente"])
            log.info(f"Engie: {aantal} prijssensoren bijgewerkt")

        aantal_fouten = len(r1["fouten"]) + len(r2["fouten"])
        if aantal_fouten:
            niveau = "fout"
        elif r2["controle_fouten"] or (r1["pdf_gevonden"] == 0 and not r2["prijzen"]):
            niveau = "waarschuwing"
        else:
            niveau = "ok"

        if r1["pdf_gevonden"] == 0:
            delen = [f"0 pdf gevonden in {PDF_MAP}"]
        else:
            delen = [f"{r1['pdf_gevonden']} pdf gevonden, {r1['nieuw']} nieuw gescand"]
        if r1["json"] in ("aangemaakt", "bijgewerkt"):
            delen.append("json " + r1["json"])
        if r2["prijzen"]:
            delen.append(f"{r2['periodes']} periodes berekend")
        if r2["controle_fouten"]:
            delen.append(f"{r2['controle_fouten']} periode(s) om na te kijken")
        if aantal_fouten:
            delen.append(f"{aantal_fouten} fout(en)")
        tekst = ", ".join(delen)

        log.info("Engie: " + tekst)
        _zet_status(niveau, tekst, r2["tijdstip"], {
            "pdf_gevonden": r1["pdf_gevonden"],
            "nieuw_gescand": r1["nieuw"],
            "overgeslagen": r1["overgeslagen"],
            "json": r1["json"],
            "periodes": r2["periodes"],
            "controle_fouten": r2["controle_fouten"],
            "fouten": (r1["fouten"] + r2["fouten"])[:5],
        })
    except Exception as e:
        log.error(f"Engie: verwerking mislukt: {e}")
        _zet_status("fout", f"Verwerking mislukt: {e}", "", {})
    finally:
        _TOESTAND["bezig"] = False


@service
def verwerk_engie_facturen(herstart=False, debug=False, **kwargs):
    """
    yaml
    name: Verwerk ENGIE-facturen
    description: >
      Scant de PDF-facturen in /media/engie, bouwt energie_historiek.json en energie_prijzen.json,
      zet de prijssensoren en ververst ha_engie_resume.html.
    fields:
      herstart:
        name: Alles opnieuw scannen
        description: Wist energie_historiek.json en scant alle PDF's opnieuw.
        default: false
        selector:
          boolean:
      debug:
        name: Uitgelezen tekst bewaren
        description: Bewaart per PDF de uitgelezen tekst in /media/engie/extracteddata/debug.
        default: false
        selector:
          boolean:
    """
    _voer_uit(herstart, debug)


@time_trigger("startup")
def engie_bij_opstart():
    """Zet de sensoren terug na een herstart van HA of een reload van pyscript."""
    _voer_uit(False, False)
    # Ook elke ochtend nieuwe PDF's oppikken? Vervang dan de decorator hierboven door:
    #   @time_trigger("startup", "cron(15 6 * * *)")
