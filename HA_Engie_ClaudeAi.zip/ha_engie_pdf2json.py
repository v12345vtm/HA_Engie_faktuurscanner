"""
ENGIE factuurscanner, stap 1 van 2: PDF-facturen -> energie_historiek.json

Plaats in:        /config/pyscript/modules/ha_engie_pdf2json.py
Gebruikt door:    /config/pyscript/ha_engie_facturen.py

Dezelfde logica als engiefactuurscanner.py (PyCharm), met drie aanpassingen voor Home Assistant:
  - de zware PDF-verwerking draait in een aparte thread (task.executor), zodat de
    HA event loop niet blokkeert;
  - alle meldingen worden verzameld en door ha_engie_facturen.py in het HA-log gezet;
  - de JSON wordt atomisch geschreven (eerst een .tmp-bestand, dan vervangen).

De scanfunctie is native python (@pyscript_compile) en bewust zelfstandig: de imports en
de hulpfuncties staan er in, zodat ze niet afhangt van andere pyscript-instellingen.
"""


@pyscript_compile
def _scan_native(pdf_map, json_bestand, debug_map, herstart, debug):
    """Draait in een thread (task.executor). Geeft een dict met resultaat en meldingen terug."""
    import json
    import logging
    import re
    from datetime import datetime
    from pathlib import Path

    logging.getLogger("pdfminer").setLevel(logging.ERROR)  # pdfminer vervuilt anders het HA-log

    meldingen = []
    fouten = []
    resultaat = {
        "tijdstip": datetime.now().astimezone().isoformat(timespec="seconds"),
        "pdf_gevonden": 0,
        "nieuw": 0,
        "overgeslagen": 0,
        "totaal_facturen": 0,
        "json": "geen",
        "fouten": fouten,
        "meldingen": meldingen,
    }

    # ------------------------------------------------------------------
    # Hulpfuncties: ongewijzigd uit engiefactuurscanner.py
    # ------------------------------------------------------------------
    def opschonen_tekst(tekst):
        """Verwijder verborgen tekens (newlines, tabs, asterisken) en dubbele spaties. """
        if not tekst:
            return None
        # Vervang newlines, tabs en overbodige witruimte door 1 enkele spatie
        schoon = re.sub(r"[\r\n\t]+", " ", str(tekst))
        schoon = re.sub(r"\s+", " ", schoon)
        # Verwijder eventuele asterisken of spaties aan de randen
        return schoon.strip(" *")

    def extract_tekst_uit_pdf(pdf_pad):
        """Leest de tekst uit de PDF met behoud van de lay-out."""
        import pdfplumber

        tekst = ""
        with pdfplumber.open(pdf_pad) as pdf:
            for page in pdf.pages:
                pagina_tekst = page.extract_text(layout=True)
                if pagina_tekst:
                    tekst += pagina_tekst + "\n"
        return tekst

    def parse_factuur_tekst(tekst, bestandspad):
        """Extraheert exact de gewenste velden uit de factuurtekst."""

        def zoek_float(pattern, text, group=1):
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                val = match.group(group).strip().replace(",", ".")
                try:
                    return float(val)
                except ValueError:
                    return None
            return None

        def zoek_int(pattern, text, group=1):
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                val = match.group(group).strip().replace(",", ".")
                try:
                    return int(val)
                except ValueError:
                    return None
            return None

        def zoek_string(pattern, text, group=1):
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                return match.group(group).strip()
            return None

        # --- ALGEMEEN ---
        factuurnummer = zoek_string(r"Factuurnummer\s+([\d\s]{10,})", tekst)
        if factuurnummer:
            factuurnummer = re.sub(r"\s+", "", factuurnummer)

        factuurdatum = zoek_string(r"Factuurdatum\s+(\d{2}\.\d{2}\.\d{4})", tekst)
        facturatieperiode = zoek_string(
            r"Facturatieperiode\s+(\d{2}\.\d{2}\.\d{4}\s*-\s*\d{2}\.\d{2}\.\d{4})",
            tekst,
        )

        # Contractdetectie
        contract_type = zoek_string(
            r"Verbruiksadres[^\n]+\n\s*([A-Za-z0-9\s]+-[^\n]+)", tekst
        )
        if not contract_type:
            contract_type = zoek_string(
                r"([A-Za-z0-9\s]+\s*-\s*(?:vaste|variabele)\s*prijs\s*-\s*\d+\s*jaar)",
                tekst,
            )

        # Als contract_type toch adresgegevens bevat, filteren we de exacte contractnaam er nog uit
        if contract_type:
            match_contract = re.search(
                r"([A-Za-z0-9\s]+?\s*-\s*(?:vaste|variabele)\s*prijs\s*-\s*\d+\s*jaar)",
                contract_type,
                re.IGNORECASE,
            )
            if match_contract:
                contract_type = match_contract.group(1)

        # --- FINANCIEEL TOTAAL ---
        totaal_excl_btw = zoek_float(
            r"Totaal\s*\(\€\s*excl\.\s*btw\)[^\d]*([\d]+[\.,]\d{2})", tekst
        )
        btw = zoek_float(r"\n\s*Btw[^\d]*([\d]+[\.,]\d{2})", tekst)
        totaal_incl_btw = zoek_float(
            r"Totaal\s*\(\€\s*incl\.\s*btw\)[^\d]*([\d]+[\.,]\d{2})", tekst
        )
        totaal_te_betalen = zoek_float(
            r"Totaal te betalen \(incl\. btw\)\s*([\d]+[\.,]\d{2})\s*€", tekst
        )

        # --- ELEKTRICITEIT ---
        elek_ean = zoek_string(r"Elektriciteit\s*–?\s*EAN\s*(\d{18,})", tekst)
        elek_afname_engie = zoek_float(
            r"Afname - dit betaal je aan ENGIE[^\d]*([\d]+[\.,]\d{2})", tekst
        )
        elek_netwerkkosten = zoek_float(
            r"Netwerkkosten - dit storten wij door aan de netbeheerder[^\d]*([\d]+[\.,]\d{2})",
            tekst,
        )
        elek_toeslagen = zoek_float(
            r"Toeslagen en heffingen - dit storten wij door aan de overheid[^\d]*([\d]+[\.,]\d{2})",
            tekst,
        )

        elek_piek_kwh = zoek_int(r"Piekuren[^\d]*(\d+)\s*kWh", tekst)
        elek_dal_kwh = zoek_int(r"Daluren[^\d]*(\d+)\s*kWh", tekst)
        elek_totaal_kwh = zoek_int(r"Totaal afname[^\d]*(\d+)\s*kWh", tekst)

        # --- AARDGAS ---
        gas_ean = zoek_string(r"Aardgas\s*–?\s*EAN\s*(\d{18,})", tekst)
        gas_verbruik_engie = zoek_float(
            r"Verbruik - dit betaal je aan ENGIE[^\d]*([\d]+[\.,]\d{2})", tekst
        )

        gas_netwerkkosten = None
        net_matches = re.findall(
            r"Netwerkkosten - dit storten wij door aan de netbeheerder[^\d]*([\d]+[\.,]\d{2})",
            tekst,
        )
        if len(net_matches) > 1:
            gas_netwerkkosten = float(net_matches[1].replace(",", "."))

        gas_toeslagen = None
        toeslag_matches = re.findall(
            r"Toeslagen en heffingen - dit storten wij door aan de overheid[^\d]*([\d]+[\.,]\d{2})",
            tekst,
        )
        if len(toeslag_matches) > 1:
            gas_toeslagen = float(toeslag_matches[1].replace(",", "."))

        gas_kwh = zoek_int(r"Verbruik[^\d]*(\d+)\s*kWh", tekst)
        gas_m3 = zoek_int(r"(\d+)\s*m3", tekst)

        # Bij het vullen van de JSON halen we alle tekst-velden door opschonen_tekst()
        return {
            "bronbestand": Path(bestandspad).name,
            "contract": opschonen_tekst(contract_type),
            "factuurnummer": opschonen_tekst(factuurnummer),
            "factuurdatum": opschonen_tekst(factuurdatum),
            "facturatieperiode": opschonen_tekst(facturatieperiode),
            "elektriciteit": {
                "ean": opschonen_tekst(elek_ean),
                "afname_engie": elek_afname_engie,
                "netwerkkosten": elek_netwerkkosten,
                "toeslagen_en_heffingen": elek_toeslagen,
                "piek_kwh": elek_piek_kwh,
                "dal_kwh": elek_dal_kwh,
                "totaal_afname_kwh": elek_totaal_kwh,
            },
            "aardgas": {
                "ean": opschonen_tekst(gas_ean),
                "verbruik_engie": gas_verbruik_engie,
                "netwerkkosten": gas_netwerkkosten,
                "toeslagen_en_heffingen": gas_toeslagen,
                "verbruik_kwh": gas_kwh,
                "verbruik_m3": gas_m3,
            },
            "totaalbedragen": {
                "totaal_excl_btw": totaal_excl_btw,
                "btw": btw,
                "totaal_incl_btw": totaal_incl_btw,
                "totaal_te_betalen": totaal_te_betalen,
            },
        }

    # ------------------------------------------------------------------
    # Map doorlopen (= verwerk_pdf_folder uit het PyCharm-script)
    # ------------------------------------------------------------------
    try:
        pdf_folder = Path(pdf_map)
        json_pad = Path(json_bestand)

        if not pdf_folder.exists():
            pdf_folder.mkdir(parents=True, exist_ok=True)
            meldingen.append(("warning", f"map {pdf_map} bestond niet en is aangemaakt: zet de PDF-facturen daar"))
        json_pad.parent.mkdir(parents=True, exist_ok=True)

        if herstart and json_pad.exists():
            json_pad.unlink()
            meldingen.append(("info", f"[HERSTART] {json_pad.name} gewist: alle PDF's worden opnieuw gescand"))

        json_bestond = json_pad.exists()
        bestaande_data = []
        verwerkte_bestanden = set()
        if json_bestond:
            try:
                bestaande_data = json.loads(json_pad.read_text(encoding="utf-8"))
                if not isinstance(bestaande_data, list):
                    raise ValueError("verwacht een lijst met facturen")
                for item in bestaande_data:
                    if "bronbestand" in item:
                        verwerkte_bestanden.add(item["bronbestand"])
            except (ValueError, TypeError, OSError) as e:
                bestaande_data = []
                verwerkte_bestanden = set()
                meldingen.append(("warning", f"{json_pad.name} is onleesbaar ({e}): alle PDF's worden opnieuw gescand"))

        pdf_bestanden = sorted(
            [p for p in pdf_folder.iterdir() if p.is_file() and p.suffix.lower() == ".pdf"],
            key=lambda p: p.name.lower(),
        )
        resultaat["pdf_gevonden"] = len(pdf_bestanden)

        if not pdf_bestanden:
            meldingen.append(("warning", f"0 pdf gevonden in map {pdf_map}"))
            resultaat["totaal_facturen"] = len(bestaande_data)
            resultaat["json"] = "ongewijzigd" if json_bestond else "geen"
            return resultaat

        debug_aantal = 0
        for pdf_path in pdf_bestanden:
            naam = pdf_path.name

            if naam in verwerkte_bestanden:
                resultaat["overgeslagen"] += 1
                meldingen.append(("debug", f"overslaan, reeds verwerkt: {naam}"))
                continue

            meldingen.append(("debug", f"verwerken: {naam}"))
            try:
                tekst = extract_tekst_uit_pdf(pdf_path)

                if debug:
                    dbg_map = Path(debug_map)
                    dbg_map.mkdir(parents=True, exist_ok=True)
                    (dbg_map / (pdf_path.stem + ".txt")).write_text(tekst, encoding="utf-8")
                    debug_aantal += 1

                factuur_json = parse_factuur_tekst(tekst, pdf_path)
                bestaande_data.append(factuur_json)
                verwerkte_bestanden.add(naam)
                resultaat["nieuw"] += 1

            except ImportError:
                fouten.append("pdfplumber ontbreekt")
                meldingen.append(("error", "pdfplumber is niet geinstalleerd: voeg 'pdfplumber' toe aan "
                                           "/config/pyscript/requirements.txt en herstart Home Assistant"))
                break
            except Exception as e:
                fouten.append(f"{naam}: {e}")
                meldingen.append(("error", f"kon {naam} niet verwerken: {e}"))

        if debug_aantal:
            meldingen.append(("info", f"{debug_aantal} debug-tekstbestand(en) opgeslagen in {debug_map}"))

        meldingen.append((
            "info",
            f"{len(pdf_bestanden)} pdf gevonden in {pdf_map}: {resultaat['nieuw']} gescand, "
            f"{resultaat['overgeslagen']} overgeslagen (reeds verwerkt), {len(fouten)} fout(en)",
        ))

        if resultaat["nieuw"] > 0:
            tmp = json_pad.with_name(json_pad.name + ".tmp")
            tmp.write_text(json.dumps(bestaande_data, ensure_ascii=False, indent=4), encoding="utf-8")
            tmp.replace(json_pad)
            resultaat["json"] = "bijgewerkt" if json_bestond else "aangemaakt"
            meldingen.append((
                "info",
                f"{json_pad.name} {resultaat['json']}: {resultaat['nieuw']} nieuwe factuur/facturen, "
                f"{len(bestaande_data)} in totaal",
            ))
        else:
            resultaat["json"] = "ongewijzigd" if json_bestond else "geen"
            meldingen.append(("info", "geen nieuwe facturen om toe te voegen"))

        resultaat["totaal_facturen"] = len(bestaande_data)

    except Exception as e:
        fouten.append(str(e))
        meldingen.append(("error", f"onverwachte fout: {e}"))

    return resultaat


def engie_pdf2json(pdf_map, json_bestand, debug_map, herstart=False, debug=False):
    """Scant de PDF-map. De zware verwerking draait in een thread via task.executor."""
    return task.executor(_scan_native, pdf_map, json_bestand, debug_map, herstart, debug)
